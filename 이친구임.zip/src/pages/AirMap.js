import React from 'react';

const AirMap = () => {
  return <div>AirMap</div>;
};

export default AirMap;
