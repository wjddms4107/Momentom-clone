import React from 'react';

const AirCart = () => {
  return <div>AirCart</div>;
};

export default AirCart;
