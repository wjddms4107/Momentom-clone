export const BASE_URL = 'http://10.58.7.15:8000';

// import { GET_PRODUCT_API } from '../../../config.js';
// fetch(`${GET_PRODUCT_API}/5`).then(...).then(...);
